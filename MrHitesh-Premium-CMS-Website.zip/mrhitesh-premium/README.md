# MrHitesh.com — Gujarati News & Blog

Premium Gujarati static website with mobile-friendly visual article admin through **Pages CMS**, hosted on **Cloudflare Pages**.

## Important
The sample posts are demos, NOT actual news. Replace with verified original content before launching. This is a functional starter, not a deployed site. The CMS dashboard is hosted separately at https://app.pagescms.org/ (it is not an `/admin` page on the website).

## Quick start (no coding needed to publish posts)
1. Sign up for GitHub (if eligible; use a parent/guardian if needed). Create a new repository, e.g. `mrhites-website`. Upload **all files in this ZIP including `.pages.yml`**, keeping folder structure. GitHub's web upload sometimes hides dotfiles on certain devices; verify `.pages.yml` appears at the root.
2. Visit https://dash.cloudflare.com/ → Workers & Pages → Create → Pages → **Connect to Git** (not Direct Upload). Connect your GitHub repository.
3. Build command: `node build.js`; output directory: `dist`; framework: None. Deploy. You will receive a free `*.pages.dev` address.
4. Visit https://app.pagescms.org/ → Sign in with GitHub → authorize Pages CMS for your repository → choose the repository → `Gujarati Articles` → create/edit posts, upload cover images and save.
5. Cloudflare detects commits and rebuilds the live website automatically. Changes may take a short time to deploy.
6. Later buy `mrhitesh.com` if available, and connect it through Cloudflare Pages → Custom domains. Domain registration is paid; hosting can remain free within plan limits.

## Preview on computer
Run `node build.js`, then serve the `dist` directory with any local static server. Opening `dist/index.html` directly can have issues with root-relative asset paths, so a server is recommended.

## Security and publishing
- Do not put GitHub tokens or passwords in website files.
- Use GitHub authentication to access Pages CMS; give repository access only to trusted people.
- Avoid uploading private information, unlicensed images, or unverified news.
- The site uses Google Fonts, which require internet connectivity.
- CMS stores posts and images in GitHub; GitHub/Cloudflare free tier limits apply.

## File structure
- `.pages.yml` — Pages CMS admin fields
- `content/posts/` — Markdown articles
- `media/` — Uploaded cover images
- `assets/` — Design CSS and JavaScript
- `build.js` — Builds static pages in `dist/`
